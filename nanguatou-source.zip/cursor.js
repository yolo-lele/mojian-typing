(() => {
  'use strict';
  const cursor = document.getElementById('toyCursor');
  const root = document.documentElement;
  const finePointer = matchMedia('(hover: hover) and (pointer: fine)');
  let ready = cursor.complete && cursor.naturalWidth > 0;
  const hide = () => root.classList.remove('toy-cursor-active');
  cursor.addEventListener('load', () => { ready = cursor.naturalWidth > 0; });
  cursor.addEventListener('error', () => { ready = false; hide(); });
  function syncLayer() {
    const parent = document.querySelector('dialog[open]') || document.body;
    if (cursor.parentElement !== parent) parent.append(cursor);
  }
  function position(event) {
    if (!ready || !finePointer.matches || event.pointerType !== 'mouse') { hide(); return; }
    // Native dialogs and the toy need to share the browser's top layer.
    syncLayer();
    cursor.style.setProperty('--pointer-x', event.clientX + 'px');
    cursor.style.setProperty('--pointer-y', event.clientY + 'px');
    root.classList.add('toy-cursor-active');
  }
  document.addEventListener('pointermove', position, { passive: true });
  document.addEventListener('pointerdown', position, { passive: true });
  document.addEventListener('pointerout', event => { if (!event.relatedTarget) hide(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) hide(); });
  const layerObserver = new MutationObserver(syncLayer);
  document.querySelectorAll('dialog').forEach(dialog => layerObserver.observe(dialog, { attributes: true, attributeFilter: ['open'] }));
  window.addEventListener('blur', hide);
  finePointer.addEventListener('change', hide);
})();
