const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const dir=__dirname;
const assets=new Map();
const htmlAssets=new Set();
const mime={'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.webp':'image/webp'};
function embed(relative){
  if(assets.has(relative))return assets.get(relative).id;
  const file=path.resolve(dir,relative);
  if(!file.startsWith(dir+path.sep))throw new Error('Asset outside dist');
  const type=mime[path.extname(file)];if(!type)throw new Error('Unknown asset '+relative);
  const id='embedded-asset-'+assets.size;
  assets.set(relative,{id,data:'data:'+type+';base64,'+fs.readFileSync(file).toString('base64')});
  return id;
}
let html=fs.readFileSync(path.join(dir,'index.html'),'utf8');
for(const sheet of ['styles.css','theme.css','cursor.css']){
  let css=fs.readFileSync(path.join(dir,sheet),'utf8');
  css=css.replace(/url\((['"]?)([^)'"\s]+)\1\)/g,(match,quote,url)=>{
    if(/^(data:|https?:|#)/i.test(url))return match;
    embed(url);
    return 'url("'+assets.get(url).data+'")';
  });
  html=html.replace('<link rel="stylesheet" href="'+sheet+'">',()=>'<style>'+css+'</style>');
}
html=html.replace(/<img\b([^>]*?)\bsrc="([^"]+)"/g,(match,attributes,url)=>{
  if(/^(data:|https?:)/i.test(url))return match;
  const id=embed(url);htmlAssets.add(id);
  return '<img'+attributes+'data-embedded-asset="'+id+'"';
});
html=html.replace('href="favicon.svg"',()=>'href="data:image/svg+xml,'+encodeURIComponent(fs.readFileSync(path.join(dir,'favicon.svg'),'utf8'))+'"');
const scripts=['core.js','articles.js','dictation.js','app.js','cursor.js'];
for(const file of scripts)html=html.replace('<script src="'+file+'" defer></script>','');
const table=Object.fromEntries([...assets.values()].filter(a=>htmlAssets.has(a.id)).map(a=>[a.id,a.data]));
const loader='(()=>{const assets='+JSON.stringify(table)+';document.querySelectorAll("img[data-embedded-asset]").forEach(img=>{img.src=assets[img.dataset.embeddedAsset];});})();';
const source=scripts.map(file=>fs.readFileSync(path.join(dir,file),'utf8'));
[loader,...source].forEach(js=>new vm.Script(js));
html=html.replace('</body>',()=>[loader,...source].map(js=>'<script>\n'+js.replace(/<\/script/gi,()=>'<\\/script')+'\n</script>').join('\n')+'\n</body>');
const output=path.resolve(process.argv[2] || path.join(__dirname,'standalone.html'));
html=html.replace(/\r\n/g,'\n');
fs.writeFileSync(output,html);
console.log(JSON.stringify({output,bytes:fs.statSync(output).size,characters:html.length,assets:assets.size,externalScripts:/<script\s+src=/.test(html)}));
