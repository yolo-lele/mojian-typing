"""Build practice entries from captured court documents, without length limits."""
import json, pathlib, re
ROOT = pathlib.Path(__file__).parent
cases = json.loads((ROOT/'sources/cases.json').read_text(encoding='utf-8'))
EXTRA_FACTS = {
 '2505': '2018年11月18日，被告王某某向原告出具借条，载明借款25460元，并约定于2018年12月30日前还清。2019年11月26日，双方在有关建筑设备租赁合同纠纷执行案件中达成协议，被告承担相关设备租金及损失。当日，被告另向原告借款10000元用于支付执行款项。原告主张上述两笔借款合计35460元尚未清偿，现提起诉讼，请求依法支持原告的诉讼请求。',
 '2492': '原告提供劳务后，被告高某某拖欠工资25660元。经催要，2021年3月10日，被告高某某为原告出具工资证明，载明工人工资25660元，并写有由周某某代发的内容。该证明部分内容由被告周某某书写，代发内容由高某某书写。原告未收到上述欠付工资，现依据该工资证明向二被告主张支付工资款，并请求依法处理本案诉讼费用。',
 '2533': '2015年至2016年间，被告陈某多次向原告购买水泵、水管、电线、电缆等货物，未付清货款。2018年8月6日，双方结算后，被告陈某向原告出具欠条，载明水泵、水管等货款44000元，原有单据作废。原告主张三被告系合伙关系，要求共同偿还上述货款及利息。因款项未能清偿，原告提起本案诉讼，请求依法处理。',
}
EVIDENCE = {
 '2505':'借条、2019年11月26日保证书。', '2482':'被告出具的欠条。',
 '2492':'2021年3月10日工资证明。', '2519':'《恒博建筑器材租赁合同（塔吊）》。',
 '2502':'模板工程施工承包合同、工程款收付记录。', '2513':'被告出具的73000元欠条。',
 '2503':'送货单、银行交易明细、微信转账电子凭证、微信聊天记录截图、对账单。',
 '2531':'借条、证人证言。', '2517':'《液化石油气购销合同》、交易通知单、《液化天然气购销合同》。',
 '2489':'被告出具的欠条。', '2509':'送货单复印件。', '2521':'欠条、原告与被告的录音。',
 '2533':'2018年8月6日欠条。', '2501':'微信聊天记录。', '2523':'借条、微信及支付宝转账电子回单。',
 '2516':'借条、保证书、转账凭条。', '2522':'借条。', '2499':'银行转账明细、微信转账记录、微信聊天记录、双方录音。',
 '2530':'借条。', '2526':'借款合同、转账记录、75000元收据、律师事务所见证书。',
 '2510':'借条、存款凭条、通话录音、微信聊天记录。', '2481':'银行交易明细、支付宝交易流水证明、微信聊天记录。',
 '2477':'借条、证人证言。', '2486':'借款合同、借款借据、展期借款协议、贷款发放通知单、抵押合同及抵押贷款协议书。',
 'rz3599':'最高额借款合同、划款授权书、共同承担债务承诺书。'
}
TOPICS = ['借条与执行款借款','烟酒货款','劳务工资与代发争议','塔吊租赁与返还','模板工程劳务款','欠款与逾期利息','油漆货款与对账','黄沙货款','液化石油气预付款','饲料款履行期限','熟食送货与责任主体','化肥赊销款','水泵水管货款','借呗转借与还款抵扣','借款与担保责任','借款预扣利息','借款到期未还','生意周转借款','约定月息借款','现金与转账借款','借款与投资争议','多次转账借款','借条换据与利息','金融借款与房屋抵押','金融借款与共同债务']

articles=[]
for index,case in enumerate(cases):
    key=case['key']; text=case['text']; lines=text.splitlines()
    court='河南省汝州市人民法院' if key=='rz3599' else lines[0]
    # Preserve the parties as disclosed, without guessing hidden identities or contact details.
    party_lines=[]; in_parties=False
    for line in lines:
        if re.match(r'原告[：:]',line): in_parties=True
        if in_parties:
            if line.startswith('原告') and not re.match(r'原告[：:]',line): break
            party_lines.append(line)
    # Do not include defendants' representatives in the rewritten plaintiff's pleading.
    parties=[]; defendant=False
    for line in party_lines:
        if re.match(r'被告[：:]',line): defendant=True
        if not defendant or re.match(r'(被告|法定代表人)[：:]',line): parties.append(line)
    assert parties and any(x.startswith('被告') for x in parties),key
    plaintiff=re.split(r'[，,。]',re.sub(r'^原告[：:]','',parties[0]))[0]
    if key in EXTRA_FACTS:
        paragraph=next(line for line in lines if '请求判令：' in line)
        request=paragraph.split('请求判令：',1)[1].split('本院受理后',1)[0]
        facts=EXTRA_FACTS[key]
    else:
        match=re.search(r'原告[^\n]*?向本院(?:提出(?:如下)?诉讼请求(?:是)?|起诉请求)[：:](.*?)(?=\n被告)',text,re.S)
        assert match,key
        pieces=re.split(r'事实[与和及]理由[：:]',match[1],maxsplit=1)
        assert len(pieces)==2,key
        request,facts=(p.strip() for p in pieces)
    # Restructure only the recorded allegations; no invented signatures, filing dates or evidence counts.
    request=re.sub(r'(?<=[；。;])\s*(?=[1-9][、.．])','\n',request)
    complaint='\n'.join(['民事起诉状（依据公开判决书改写）',*parties,'诉讼请求：',request,'事实与理由：',facts,'证据和证据来源：',EVIDENCE[key],'此致',court,'起诉人：'+plaintiff,'具状日期：未见公开记载'])
    complaint=re.sub(r'[\r\n\u2028\u2029]', '', complaint)
    source={'title':case['title']+' · '+('汝州市法院网' if key=='rz3599' else '永城市法院网'),'url':case['url']}
    common=dict(language='zh',jurisdiction='中国大陆',caseNumber=case['caseNumber'],sources=[source],collectedAt='2026-10-22')
    topic=TOPICS[index]
    # Continuous typing: remove paragraph breaks only; keep the captured source intact.
    judgment_text=re.sub(r'[\r\n\u2028\u2029]', '', text)
    articles.append(dict(**common,id='civil-judgment-'+key,title=topic+'｜民事判决书原文',category='民事判决书',difficulty='原文',description=case['caseNumber']+' · 法院公开原文',text=judgment_text,sourceKey=key,sourceSha256=case['sha256'],contentKind='judgment-original',sourceNote='法院官网公开判决书，保留公开文本及匿名方式，练习文本去除段落换行以便连续输入，其余公开文本及标点保留，不按字数裁剪。源码中保留带段落的来源快照及校验值。历史文书中的法律引用、原网站笔误及当事人不同主张均按来源保留。'))
    articles.append(dict(**common,id='civil-complaint-'+key,title=topic+'｜民事起诉状改写',category='民事起诉状',difficulty='改写',description=case['caseNumber']+' · 依据真实案件改写',text=complaint,sourceKey=key,contentKind='complaint-adapted',sourceNote='依据所链接真实判决书记载的当事人、起诉请求和案件事实整理为速录练习稿，并非当事人提交的起诉状原件。练习文本去除所有段落换行，整篇连续输入。保留原告主张与法院认定之间的区别；未公开的具状日期不作补写。'))
assert len(articles)==50
(ROOT/'articles.js').write_text('// 25 public court judgments and 25 clearly labelled adapted complaints. No length limit.\nwindow.TYPING_ARTICLES = '+json.dumps(articles,ensure_ascii=False,indent=2)+';\n',encoding='utf-8')
(ROOT/'legal-sources.json').write_text(json.dumps({'collectedAt':'2026-10-22','note':'公开裁判文书用于速录练习；起诉状为基于真实案例的改写稿。','cases':[{k:v for k,v in c.items() if k!='text'} for c in cases]},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'articles':len(articles),'judgments':25,'adaptedComplaints':25,'shortest':min(len(a['text']) for a in articles),'longest':max(len(a['text']) for a in articles)},ensure_ascii=False))
