const test=require('node:test');
const assert=require('node:assert/strict');
const {splitText,spokenText,createPlayer}=require('../dictation.js');
function setup(){
  const spoken=[],timers=new Map(),errors=[];let id=0;
  const synthesis={cancel(){},speak(u){spoken.push(u)}};
  const player=createPlayer({synthesis,Utterance:class{constructor(text){this.text=text}},onError:e=>errors.push(e),schedule:fn=>{timers.set(++id,fn);return id},unschedule:n=>timers.delete(n)});
  return {player,spoken,timers,errors};
}
test('splitting preserves all Unicode, spaces and normalized newlines without truncation',()=>{
  const text='民事判决书\r\n第一条。'+('甲😀 '.repeat(100))+'第二条；终。';
  const parts=splitText(text);
  assert.equal(parts.join(''),text.replace(/\r\n/g,'\n'));
  assert.ok(parts.every(p=>Array.from(p).length<=72));
  assert.deepEqual(splitText(''),[]);
});
test('punctuation can be read aloud while decimal numbers remain intact',()=>{
  assert.equal(spokenText('赔偿1.25元，\n'), '赔偿1.25元 逗号  换行 ');
  assert.equal(spokenText('原告，甲。',false),'原告，甲。');
  assert.match(spokenText('甲 乙'),/空格/);
});
test('single phrase stops and navigation respects boundaries',()=>{
  const {player,spoken,timers}=setup();player.load('第一句。第二句。');player.play();
  spoken.at(-1).onend();assert.equal(player.snapshot().status,'ready');assert.equal(timers.size,0);
  player.move(1);assert.equal(player.snapshot().index,1);spoken.at(-1).onend();assert.equal(player.snapshot().status,'ended');
  player.move(1);assert.equal(player.snapshot().index,1);player.move(-10);assert.equal(player.snapshot().index,0);
});
test('continuous reading advances after the gap; pause cancels pending advancement',()=>{
  const {player,spoken,timers}=setup();player.load('甲。乙。丙。');player.configure({continuous:true});player.play();
  spoken.at(-1).onend();assert.equal(player.snapshot().status,'gap');
  const advance=[...timers.values()][0];advance();assert.equal(player.snapshot().index,1);
  spoken.at(-1).onend();const stale=[...timers.values()].at(-1);player.pause();stale();
  assert.equal(player.snapshot().index,1);assert.equal(player.snapshot().status,'paused');
  player.play();assert.match(spoken.at(-1).text,/乙/);
});
test('replacing a document invalidates old callbacks and starts at the first phrase',()=>{
  const {player,spoken,errors}=setup();player.load('旧文。下一句。');player.play();
  const oldEnd=spoken.at(-1).onend,oldError=spoken.at(-1).onerror;
  player.load('新文。');oldEnd();oldError({error:'canceled'});
  assert.deepEqual(player.snapshot(),{index:0,total:1,status:'idle'});assert.deepEqual(errors,[]);
  player.play();assert.match(spoken.at(-1).text,/新文/);
});
test('voice and rate apply on replay and failed speech can be retried',()=>{
  const {player,spoken,errors}=setup(),voice={lang:'zh-CN'};
  player.load('甲。');player.configure({voice,rate:.6,punctuation:false});player.play();
  assert.equal(spoken[0].voice,voice);assert.equal(spoken[0].rate,.6);assert.equal(spoken[0].text,'甲。');
  spoken[0].onerror({error:'network'});assert.deepEqual(errors,['network']);assert.equal(player.snapshot().status,'error');
  player.play();assert.equal(player.snapshot().status,'playing');player.stop();assert.equal(player.snapshot().status,'idle');
});
