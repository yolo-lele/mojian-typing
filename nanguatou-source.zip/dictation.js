(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.TypingDictation=api;
})(typeof window!=='undefined'?window:globalThis,()=>{
  'use strict';
  // Preserve every target character; split long legal paragraphs into speakable phrases.
  function splitText(text,max=72){
    const pieces=[];let part='';
    for(const character of Array.from(String(text).replace(/\r\n?/g,'\n'))){
      part+=character;
      if(/[。！？；\n]/.test(character)||Array.from(part).length>=max){pieces.push(part);part='';}
    }
    if(part)pieces.push(part);
    return pieces;
  }
  function spokenText(text,punctuation=true){
    if(!punctuation)return text;
    const names={'，':'逗号','。':'句号','、':'顿号','；':'分号','：':'冒号','？':'问号','！':'感叹号','（':'左括号','）':'右括号','(':'左括号',')':'右括号','《':'左书名号','》':'右书名号','“':'左双引号','”':'右双引号','‘':'左单引号','’':'右单引号','【':'左方括号','】':'右方括号','[':'左方括号',']':'右方括号','\n':'换行','\t':'制表符',' ':'空格',',':'英文逗号',';':'英文分号',':':'英文冒号','%':'百分号','％':'全角百分号','‰':'千分号','＋':'加号','+':'加号','=':'等于号','×':'乘号','／':'斜杠','/':'斜杠','—':'破折号','…':'省略号'};
    const chars=Array.from(text);
    return chars.map((c,i)=>{
      if(c==='.')return /\d/.test(chars[i-1]||'')&&/\d/.test(chars[i+1]||'')?c:' 英文句点 ';
      return names[c]?' '+names[c]+' ':c;
    }).join('');
  }
  function createPlayer({synthesis,Utterance,onChange=()=>{},onError=()=>{},schedule=setTimeout,unschedule=clearTimeout}){
    let parts=[],index=0,status='idle',generation=0,timer=null,utterance=null;
    let settings={rate:0.8,voice:null,lang:'zh-CN',punctuation:true,continuous:false,gap:3000};
    const snapshot=()=>({index,total:parts.length,status});
    const changed=()=>onChange(snapshot());
    function cancel(){
      generation++;
      if(timer!==null)unschedule(timer);
      timer=null;
      if(utterance){utterance.onend=null;utterance.onerror=null;utterance.onstart=null;}
      utterance=null;
      synthesis.cancel();
    }
    function play(){
      if(!parts.length)return;
      cancel();const token=generation;
      const speech=new Utterance(spokenText(parts[index],settings.punctuation));
      utterance=speech;
      speech.lang=settings.voice?.lang||settings.lang;speech.voice=settings.voice;speech.rate=settings.rate;
      status='playing';changed();
      speech.onend=()=>{
        if(token!==generation)return;
        utterance=null;
        if(settings.continuous&&index<parts.length-1){
          status='gap';changed();
          timer=schedule(()=>{if(token!==generation)return;timer=null;index++;play();},settings.gap);
        }else{status=index===parts.length-1?'ended':'ready';changed();}
      };
      speech.onerror=event=>{
        if(token!==generation)return;
        utterance=null;status='error';changed();onError(event.error||'unknown');
      };
      try{synthesis.speak(speech);}catch{status='error';changed();onError('unavailable');}
    }
    return {
      snapshot,
      load(text,lang='zh-CN'){cancel();parts=splitText(text);index=0;status='idle';settings.lang=lang;changed();},
      configure(options){Object.assign(settings,options);},
      play,
      pause(){if(['playing','gap'].includes(status)){cancel();status='paused';changed();}},
      stop(){cancel();status='idle';changed();},
      move(delta){cancel();index=Math.max(0,Math.min(parts.length-1,index+delta));status='ready';changed();play();}
    };
  }
  return {splitText,spokenText,createPlayer};
});
