# 一猫变喵全系列粉色背景海报

- 文件：`cat-mode-all-pink-poster.png`
- 用途：本地预览的网页背景，暂未部署。
- 生成方式：内置 `image_gen.imagegen`，非 CLI；先完整生成，再仅修正左上 Calico 的三花色块。
- 官方款式来源：[POP MART — THE MONSTERS CAT MODE ON Series Vinyl Plush Pendant Blind Box](https://www.popmart.com/ca/products/9210/the-monsters-cat-mode-on-series-vinyl-plush-pendant-blind-box)。
- 完整官方参考下载及来源映射：`tmp/cat-mode-all-references/catalog.json`，包含 10 款名称、9 常规及 1 隐藏、外貌描述与官方图片 URL。
- 制作前已逐张查看全部 10 张官方图片。内置工具每次最多接受 5 张本地参考，因此首轮传入 Cow、Persian、Midnight、Leopard、Maine Coon 五张差异最大的参考，完整描述其余款式；修正轮传入成图及 Calico 官方单图。
- 图像是重新生成的粉色摄影风格合成海报，并非官方原始宣传海报。

## 款式与布局核验

左列从上到下：
1. Calico Kitty（三花、绿色眼睛、蜜桃长缎带）
2. Persian Kitty（全白、棕蓝异瞳、冰蓝长缎带）
3. Ragdoll Kitty（米灰深棕、蓝眼、棕色缎带）
4. Cow Kitty（黑白肚子、蓝绿眼、棕绿织物领结）
5. Strawberry Kitty（粉紫奶白、绿眼、淡紫缎带）

右列从上到下：
1. Matcha Kitty（抹茶绿、琥珀眼、绿缎带）
2. Midnight Kitty（全黑、绿眼、红色短领结）
3. Leopard Kitty（豹纹、金眼、格纹短领结）
4. Siamese Kitty（奶白深巧克力棕、蓝眼、藏青短领结）
5. Maine Coon Kitty（隐藏款；银灰长毛、灰紫眼、银灰短领结）

共 10 个独立脸部，左右各 5 款，无重复款式。所有脸部位于左右外侧，中央留出约 62% 的浅粉区域。根任务已在 1920×1080 网页实屏中确认 1180px 练习卡不会遮挡脸部。底部玩偶部分脚部接近画面边界，脸部、猫套和领结均完整可见。

## 首轮完整提示词

```text
Use case: product-mockup / compositing.
Asset type: a wide 16:9 photographic pink wallpaper for a website at 1920 x 1080. Create a finished background image with exactly TEN different THE MONSTERS CAT MODE ON (一猫变喵) plush dolls, using the five supplied official references plus the complete ten-variant specification below. This is a decorative all-series poster, not a website UI.
The supplied images are reference images only: image 1 Cow, image 2 Persian, image 3 Midnight, image 4 Leopard, image 5 Maine Coon. Preserve those exact identities. The full lineup description, including the other five variants inspected from official source images, is:
Variant 1: Calico Kitty — white/ginger orange/dark-brown patchwork plush, green eyes, peach satin ribbon.
Variant 2: Persian Kitty — snowy white plush, heterochromia eyes (viewer-left golden brown, viewer-right blue), pale icy-blue satin ribbon.
Variant 3: Ragdoll Kitty — beige taupe plush, dark brown ears/arms/tail, blue eyes, brown satin ribbon.
Variant 4: Cow Kitty — black plush hood and limbs, white cheek tufts, white belly, blue-green eyes, textured brown-green tweed bow tie.
Variant 5: Strawberry Kitty — pale pink-lilac plush, cream belly, olive-green eyes, lavender satin ribbon.
Variant 6: Matcha Kitty — pale yellow-green plush, amber brown eyes, olive-green satin ribbon.
Variant 7: Midnight Kitty — all-black plush including belly, olive-green eyes, vivid red fabric bow tie.
Variant 8: Leopard Kitty — caramel and dark brown leopard-marked plush, golden eyes, dark brown and cream small checked bow tie.
Variant 9: Siamese Kitty — cream-white plush face hood and torso with dark chocolate brown ears/arms/tail, vivid blue eyes, navy knitted bow tie.
Variant 10: Maine Coon Kitty (secret) — distinctive extra-shaggy silver-gray plush, long bushy silver-gray tail, dark gray-violet eyes, silver nose and metallic silver-gray bow tie.
Preserve all identities and costume color blocking from the references and descriptions. They have LABUBU vinyl smiling faces, triangular teeth, tall plush LABUBU ears plus two smaller cat ears. These are fluffy plush products, not cartoon drawings.

Composition is the critical requirement: two narrow columns along far left and far right edges, exactly FIVE seated dolls in each column, ten total. Never add or omit dolls. Entire bodies, both ears, faces and feet visible; no overlap between dolls and no clipping at canvas edges. Each doll occupies about 17% of the total image height, their centers at y=10%,30%,50%,70%,90%. Left column centers x=8.5%, in this exact top-to-bottom order: Calico / Persian / Ragdoll / Cow / Strawberry. Right column centers x=91.5%, exact top-to-bottom order: Matcha / Midnight / Leopard / Siamese / Maine Coon. All faces must be completely within the outermost 18% width of the canvas on their side; the central 62% of the image from x=19% to x=81% must stay almost empty. An opaque website card will cover that center, so no part of a face may enter it. Give each doll its own soft pink satin cushion or tiny silky cloud so they sit naturally in five separate levels with consistent scale.

Scene and styling: soft blush-pink and creamy ivory satin backdrop, subtle silk ribbon curls only at the very outer edges, lovely refined feminine mood, luminous soft studio product photography, highly detailed fluffy texture, gentle natural shadows. Central 62% has only a smooth very pale pink-to-ivory glow and subtle satin texture, excellent blank space. Palette remains pastel pink overall while accurately preserving the ten different doll colors. No furniture, no fruit, no clutter, no books, no props from the references.
Constraints: EXACTLY ten distinct dolls in the prescribed two-by-five layout; do not make a grid spanning the center. No duplicate dolls, no extra heads, no text or names, no numbers, no logos, no watermark, no UI, no cards, no borders. Landscape 16:9.
```

## 三花局部修正提示词

```text
Use case: precise-object-edit. Edit image 1, the complete ten-doll pink poster. Image 2 is an official Calico Kitty reference.
Change only the TOP-LEFT doll (first of the five on the left). It is currently too striped and leopard-like. Replace this top-left doll's fur coloring with the exact broad patchwork of Calico Kitty in reference image 2: viewer-left half of face hood WHITE, viewer-right half GINGER ORANGE, one small cat ear dark brown and the other ginger orange, white tall ears, ginger orange arms, white chest/body with separate dark chocolate brown patches. Tail dark chocolate brown, NOT a striped tiger tail. Green eyes, peach/champagne pink long satin ribbon bow. Calico must have large irregular white/orange/dark brown color BLOCKS, absolutely not all-over leopard spots or tiger stripes. Keep its cute plush seated form at exactly its current position and size.
Keep all other nine dolls exactly unchanged; keep each identity, face, all bows and eye colors unchanged. Preserve the same exact poster composition, the pink satin cushions and backdrop, the wide blank center, the size, lighting, color and positions of all ten dolls. Keep exactly five dolls left and five right. No texts, logos or additional items. Do not change the leopard doll at the middle of the right column. Return the finished full 16:9 poster.
```

