'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const core = require('../core.js');

test('normalize preserves whitespace and punctuation, normalizes CRLF and NFC', () => {
  assert.equal(core.normalize('  cafe\u0301\r\n你好，世界！  '), '  café\n你好，世界！  ');
  assert.equal(core.normalize('\n '), '\n ');
});

test('characters are Unicode code points rather than UTF-16 units', () => {
  assert.deepEqual(core.chars('你😀e\u0301'), ['你', '😀', 'é']);
  const result = core.analyze('你😀é', '你😀e\u0301', 60);
  assert.equal(result.total, 3);
  assert.equal(result.typed, 3);
  assert.equal(result.correct, 3);
  assert.equal(result.speed, 3);
  assert.equal(result.complete, true);
});

test('empty input has 100% accuracy and does not complete a nonempty passage', () => {
  assert.deepEqual(core.analyze('中文。', '', 0), {
    total: 3, typed: 0, correct: 0, incorrect: 0, accuracy: 100,
    speed: 0, progress: 0, complete: false
  });
});

test('positional errors reduce accuracy and net speed', () => {
  assert.deepEqual(core.analyze('你好世界', '你号世', 30), {
    total: 4, typed: 3, correct: 2, incorrect: 1, accuracy: (2 / 3) * 100,
    speed: 4, progress: 75, complete: false
  });
});

test('completion is based on entered length even with mistakes', () => {
  const result = core.analyze('你好', '你号', 12);
  assert.equal(result.complete, true);
  assert.equal(result.progress, 100);
  assert.equal(result.accuracy, 50);
  assert.equal(result.speed, 5);
});

test('overflow counts as incorrect and progress never exceeds 100%', () => {
  const result = core.analyze('ab', 'abc', 60);
  assert.equal(result.typed, 3);
  assert.equal(result.correct, 2);
  assert.equal(result.incorrect, 1);
  assert.equal(result.progress, 100);
  assert.equal(result.complete, true);
});

test('spaces, punctuation, and normalized newlines all count', () => {
  const result = core.analyze('a b，\r\nc', 'a b，\nc', 60);
  assert.equal(result.total, 6);
  assert.equal(result.correct, 6);
  assert.equal(result.accuracy, 100);
});

test('empty target never completes or produces invalid progress', () => {
  const result = core.analyze('', 'x', 10);
  assert.equal(result.total, 0);
  assert.equal(result.progress, 0);
  assert.equal(result.complete, false);
  assert.equal(result.incorrect, 1);
  assert.equal(result.accuracy, 0);
});

test('invalid, zero, negative and infinite durations give zero speed', () => {
  for (const seconds of [0, -1, NaN, Infinity, -Infinity, undefined, 'invalid']) {
    assert.equal(core.analyze('a', 'a', seconds).speed, 0);
  }
});

test('fractional speed and percentage values remain unrounded', () => {
  const result = core.analyze('abc', 'a', 7);
  assert.equal(result.speed, 60 / 7);
  assert.equal(result.progress, (1 / 3) * 100);
});

test('a deleted mistake is reflected in a fresh positional snapshot', () => {
  assert.equal(core.analyze('abcd', 'abx', 10).incorrect, 1);
  assert.equal(core.analyze('abcd', 'ab', 11).incorrect, 0);
  assert.equal(core.analyze('abcd', 'abc', 12).accuracy, 100);
});

test('browser script exposes the same API on window', () => {
  const context = { window: {} };
  vm.runInNewContext(fs.readFileSync(require.resolve('../core.js'), 'utf8'), context);
  assert.equal(typeof context.window.TypingCore.analyze, 'function');
  assert.equal(context.window.TypingCore.analyze('abc', 'abc', 60).speed, 3);
});
