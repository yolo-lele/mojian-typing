(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const core = window.TypingCore;
  const articles = window.TYPING_ARTICLES;
  const collectionSrc = document.querySelector('.labubu-art img').src;
  const paths = {
    keyboard:'M3 5h18v14H3z M6 9h1m3 0h1m3 0h1m3 0h0 M6 12h1m3 0h1m3 0h1m3 0h0 M7 16h10',
    book:'M12 5v15 M12 5C8 2 4 3 2 4v15c3-1 7-1 10 1 3-2 7-2 10-1V4c-3-1-7-2-10 1',
    chart:'M4 3v17h17 M8 16v-5m5 5V6m5 10v-8',sun:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12 1 1M5 19l1-1M18 6l1-1',
    help:'M9 9a3 3 0 0 1 6 0c0 2-3 2-3 4 M12 16h.01 M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20',
    leaf:'M20 3c-9-2-16 2-16 8 0 5 5 8 9 5 5-3 6-8 7-13 M4 21 15 9',timer:'M9 2h6 M12 5a8 8 0 1 0 0 16 8 8 0 0 0 0-16 M12 9v4l3 2 M18 5l2-2',
    plus:'M12 5v14M5 12h14',expand:'M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5',
    speed:'M4 18a9 9 0 1 1 16 0 M12 14l5-7 M6 18h12',target:'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20 M12 6a6 6 0 1 0 0 12 6 6 0 0 0 0-12 M12 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4',
    clock:'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20 M12 6v6l4 2',flag:'M4 21V3c5-4 10 4 15 0v10c-5 4-10-4-15 0',
    shuffle:'M3 6h3c5 0 7 12 12 12h3m-4-4 4 4-4 4 M3 18h3c2 0 3-2 4-4 M14 8c1-1 2-2 4-2h3m-4-4 4 4-4 4',
    edit:'M15 5l4 4 M4 20l5-1L21 7a2 2 0 0 0-4-4L5 15z',info:'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20 M12 11v6m0-10h.01',
    pause:'M8 5v14M16 5v14',play:'M8 4l12 8-12 8z',refresh:'M20 10a8 8 0 1 0-1 7 M20 3v7h-7',
    'volume-off':'M11 4 6 8H2v8h4l5 4z M16 9l6 6m0-6-6 6',volume:'M11 4 6 8H2v8h4l5 4z M15 8a6 6 0 0 1 0 8 M18 4a11 11 0 0 1 0 16',
    arrow:'M4 12h16m-6-6 6 6-6 6',sparkles:'M12 3l3 6 6 3-6 3-3 6-3-6-6-3 6-3z M3 2v4M1 4h4',
    download:'M12 3v12m-5-5 5 5 5-5 M4 16v5h16v-5',close:'M6 6l12 12M6 18 18 6',check:'M5 12l4 4L19 6'
  };
  const icon = name => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="${paths[name] || paths.leaf}"/></svg>`;
  document.querySelectorAll('[data-icon]').forEach(el => el.innerHTML = icon(el.dataset.icon));
  const escape = text => String(text).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const HISTORY_KEY = 'mojian.history.v1';
  const CUSTOM_KEY = 'mojian.custom.v1';
  const FONT_SIZE_KEY = 'nanguatou.reference-size.v1';
  let storageAvailable = true;
  let history = [];
  try {
    const raw = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
    if (Array.isArray(raw)) history = raw.filter(r => r && typeof r.title === 'string' && typeof r.at === 'string' && Number.isFinite(Date.parse(r.at)) && ['speed','accuracy','elapsed','correct','typed','total','progress'].every(k => typeof r[k] === 'number' && Number.isFinite(r[k]) && r[k] >= 0)).slice(0,100);
  } catch { storageAvailable = false; }
  const state = {article:articles[0],mode:'free',exercise:'copy',revealed:false,peeked:false,limit:180,status:'ready',input:'',accumulated:0,startedAt:0,composing:false,pendingPause:false,sound:false,view:'practice'};
  const speechAvailable=!!(window.speechSynthesis&&window.SpeechSynthesisUtterance);
  let speechVoices=[];
  const dictation=speechAvailable?window.TypingDictation.createPlayer({synthesis:window.speechSynthesis,Utterance:window.SpeechSynthesisUtterance,onChange:renderDictation,onError:()=>{pause();$('speechStatus').textContent='朗读未成功，请更换声音后重试。';}}):null;
  let referenceChars = [], targetChars = [], toastTimer, pendingAction, audioContext, referenceSize=24, lastSecond=-1;
  const minReferenceSize=12, maxReferenceSize=32;
  try {
    const savedSize=Number(localStorage.getItem(FONT_SIZE_KEY));
    if(Number.isInteger(savedSize)&&savedSize>=minReferenceSize&&savedSize<=maxReferenceSize)referenceSize=savedSize;
  } catch {}
  function toast(message) { $('toast').textContent=message; $('toast').classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('toast').classList.remove('show'),3200); }
  function elapsed() { return state.accumulated + (state.status==='running' ? (performance.now()-state.startedAt)/1000 : 0); }
  function timeText(seconds) { const n=Math.max(0,Math.floor(seconds)); return `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`; }
  function metrics() { return core.analyze(state.article.text,state.input,elapsed()); }
  function active() { return (state.status==='running'||state.status==='paused') && (state.input.length>0||elapsed()>0); }
  function updateMetrics() {
    const m=metrics();
    $('speed').textContent=Math.round(m.speed);
    $('accuracy').textContent=m.accuracy===100?'100':m.accuracy.toFixed(1);
    $('progress').textContent=Math.floor(m.progress);
    $('typedCount').textContent=m.typed;
    $('totalCount').textContent=m.total;
    $('progressBar').style.width=`${m.progress}%`;
    $('accuracyHint').textContent=m.incorrect?`${m.incorrect} 个字符有误，可退格修改`:'保持节奏，准确优先';
    updateTime();
  }
  function updateTime() {
    $('time').textContent=state.mode==='timed'?timeText(Math.ceil(Math.max(0,state.limit-elapsed()))):timeText(elapsed());
    $('timeLabel').textContent=state.mode==='timed'?'剩余时间':'练习用时';
    $('timeHint').textContent=state.status==='ready'?'输入第一个字后开始计时':state.status==='paused'?'已暂停，休息时间不计入成绩':state.status==='finished'?'练习已结束，成绩已结算':state.mode==='timed'?'跟随节奏，时间到自动结算':'专注当下，慢慢来';
  }
  function updateStatus() {
    const labels={ready:'等待开始',running:'正在练习',paused:'已暂停',finished:'练习已结束'};
    $('statusLabel').textContent=labels[state.status];
    $('statusLabel').classList.toggle('running',state.status==='running');
    $('typingInput').disabled=state.status==='paused'||state.status==='finished';
    $('pauseOverlay').hidden=state.status!=='paused';
    $('pauseButton').disabled=!['running','paused'].includes(state.status);
    $('pauseButton').innerHTML=icon(state.status==='paused'?'play':'pause')+`<span>${state.status==='paused'?'继续':'暂停'}</span>`;
    $('finishButton').disabled=!state.input.length||state.status==='finished';
    updateTime();
    renderDictation();
  }
  function renderReference() {
    targetChars=core.chars(state.article.text);
    const frag=document.createDocumentFragment();
    referenceChars=targetChars.map(char=>{const span=document.createElement('span');span.textContent=char==='\n'?'↵\n':char;frag.append(span);return span;});
    $('reference').replaceChildren(frag);
    $('reference').setAttribute('aria-label',`对照文章：${state.article.text}`);
    $('reference').setAttribute('lang',state.article.language==='en'?'en':'zh-CN');
    $('referenceWrap').scrollTop=0;
    updateReference();
  }
  function updateReference() {
    const input=core.chars(state.input);
    referenceChars.forEach((span,i)=>span.className=i<input.length?(input[i]===targetChars[i]?'correct':'incorrect'):i===input.length?'current':'');
    const current=referenceChars[Math.min(input.length,targetChars.length-1)];
    if(current && state.status==='running' && !$('referenceWrap').hidden) {
      const box=$('referenceWrap'),rect=current.getBoundingClientRect(),container=box.getBoundingClientRect();
      if(rect.bottom>container.bottom-15||rect.top<container.top) box.scrollTop+=rect.top-container.top-box.clientHeight*.35;
    }
  }
  function reset() {
    dictation?.stop();
    state.revealed=false;state.peeked=false;
    state.status='ready';state.input='';state.accumulated=0;state.startedAt=0;state.composing=false;state.pendingPause=false;lastSecond=-1;
    $('typingInput').value='';$('compositionStatus').textContent='';
    $('articleTitle').textContent=state.article.title;$('articleCategory').textContent=state.article.category;$('articleDifficulty').textContent=state.article.difficulty;
    document.querySelectorAll('[data-mode]').forEach(b=>{b.classList.toggle('selected',b.dataset.mode===state.mode);b.setAttribute('aria-pressed',b.dataset.mode===state.mode);});
    $('durationWrap').hidden=state.mode!=='timed';$('duration').value=state.limit;
    renderArticleSource();renderReference();
    dictation?.load(state.article.text,state.article.language==='en'?'en-US':'zh-CN');
    loadSpeechVoices();renderExercise();updateMetrics();updateStatus();
  }
  function start() { if(state.status==='ready'){state.status='running';state.startedAt=performance.now();updateStatus();} }
  function pause() {
    dictation?.pause();
    if(state.status!=='running') return;
    if(state.mode==='timed'&&elapsed()>=state.limit){finish('timeout');return;}
    state.accumulated=elapsed();state.status='paused';
    if(state.composing){state.composing=false;state.pendingPause=false;$('typingInput').value=state.input;$('compositionStatus').textContent='';}
    updateStatus();updateMetrics();
  }
  function resume() {if(state.status==='paused'){state.status='running';state.startedAt=performance.now();updateStatus();$('typingInput').focus();}}
  function togglePause() {if(state.status==='running')pause();else if(state.status==='paused')resume();else dictation?.pause();}
  function soundTick() {
    if(!state.sound)return;
    try {audioContext ||= new (window.AudioContext||window.webkitAudioContext)();if(audioContext.state==='suspended')audioContext.resume();const oscillator=audioContext.createOscillator(),gain=audioContext.createGain();oscillator.type='sine';oscillator.frequency.value=520;gain.gain.setValueAtTime(.025,audioContext.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audioContext.currentTime+.045);oscillator.connect(gain);gain.connect(audioContext.destination);oscillator.start();oscillator.stop(audioContext.currentTime+.05);}catch{state.sound=false;}
  }
  function commitInput() {
    if(state.composing||['paused','finished'].includes(state.status))return;
    if(state.mode==='timed'&&state.status==='running'&&elapsed()>=state.limit){finish('timeout');return;}
    const input=core.normalize($('typingInput').value);
    if(input===state.input)return;
    if(input.length)start();
    const increased=core.chars(input).length>core.chars(state.input).length;
    state.input=input;
    updateMetrics();updateReference();updateStatus();
    if(increased)soundTick();
    if(metrics().complete)finish('complete');
  }
  function persistHistory() {
    try {localStorage.setItem(HISTORY_KEY,JSON.stringify(history));storageAvailable=true;return true;}catch{storageAvailable=false;toast('浏览器存储不可用，本次记录仅在当前页面保留。');return false;}
  }
  function finish(reason='manual') {
    if(!['running','paused'].includes(state.status))return;
    dictation?.stop();
    const actual=elapsed();
    state.accumulated=reason==='timeout'?Math.min(actual,state.limit):actual;
    state.status='finished';state.composing=false;state.pendingPause=false;
    $('typingInput').value=state.input;$('compositionStatus').textContent='';
    updateStatus();updateMetrics();
    const m=metrics();
    const record={id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),title:state.article.title,at:new Date().toISOString(),mode:state.mode,exercise:state.exercise,peeked:state.peeked,limit:state.limit,reason,elapsed:state.accumulated,...m};
    history.unshift(record);history=history.slice(0,100);const saved=persistHistory();
    $('resultTitle').textContent=reason==='complete'?'这一篇，认真打完了。':reason==='timeout'?'时间到了，进步留下。':'这一段专注，值得记录。';
    $('resultSubtitle').textContent=`${state.article.title} · ${exerciseLabel(state)} · ${state.mode==='free'?'自由练习':`${state.limit/60} 分钟挑战`} · 完成 ${Math.floor(m.progress)}%`;
    $('resultMetrics').innerHTML=`<div><strong>${Math.round(m.speed)}</strong><span>正确字符 / 分钟</span></div><div><strong>${m.accuracy.toFixed(1)}<small>%</small></strong><span>正确率</span></div><div><strong>${timeText(state.accumulated)}</strong><span>实际用时</span></div>`;
    $('resultFeedback').textContent=m.typed===0?'这次还没有提交文字，下次从第一个字开始。':m.accuracy>=98?'准确的每一字，都是稳定进步的起点。保持这份从容。':m.accuracy>=90?'节奏已经慢慢建立。下一次，试着给标点和错字多一点耐心。':'放慢一点，先让每个字符准确落位。速度会随着练习慢慢到来。';
    const entered=core.chars(state.input), errors=[];
    entered.forEach((c,i)=>{if(c!==targetChars[i]&&errors.length<12)errors.push({expected:targetChars[i],actual:c,index:i});});
    const showChar=c=>c===undefined?'（多余）':c==='\n'?'↵':c===' '?'空格':c==='\t'?'Tab':c;
    $('resultErrors').innerHTML=errors.length?`<p>回看错字 · 第几个字符：你的输入 → 原文${m.incorrect>12?'（展示前 12 处）':''}</p><div class="error-chips">${errors.map(e=>`<span class="error-chip">${e.index+1}：${escape(showChar(e.actual))} → ${escape(showChar(e.expected))}</span>`).join('')}</div>`:'';
    $('resultSaved').innerHTML=icon(saved?'check':'info')+(saved?'本次练习已保存在练习记录中':'浏览器存储不可用，请及时导出本次记录');
    renderHistory();
    if($('helpDialog').open)$('helpDialog').close();
    $('resultDialog').showModal();
  }
  function exerciseLabel(record){return record.exercise==='dictation'?'听写'+(record.peeked?'（查看过原文）':''):'对照打字';}
  function renderExercise(){
    const listening=state.exercise==='dictation';
    document.querySelectorAll('[data-exercise]').forEach(button=>{const selected=button.dataset.exercise===state.exercise;button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',selected);});
    $('dictationPanel').hidden=!listening;
    $('referenceWrap').hidden=listening&&!state.revealed;
    $('referenceLegend').hidden=listening&&!state.revealed;
    $('referenceLabel').textContent=listening?'听写练习':'对照原文';
    $('inputLabel').textContent=listening?'根据朗读输入':'对照原文输入';
    $('typingInput').placeholder=listening?'点击「播放本句」，听到后输入…':'输入第一个字，开始计时…';
    $('showDictationText').textContent=state.revealed?'隐藏原文':'查看原文';
    $('showDictationText').setAttribute('aria-expanded',state.revealed);
    document.querySelector('.reading-area').classList.toggle('listening',listening);
    renderDictation();
  }
  function renderDictation(){
    const snapshot=dictation?.snapshot()||{index:0,total:0,status:'idle'};
    const unavailable=!speechAvailable||!speechVoices.length;
    const locked=state.status==='finished';
    $('speechPlay').disabled=unavailable||locked;
    $('speechPrevious').disabled=unavailable||locked||snapshot.index===0;
    $('speechNext').disabled=unavailable||locked||snapshot.index>=snapshot.total-1;
    $('speechRepeat').disabled=unavailable||locked;
    const playing=['playing','gap'].includes(snapshot.status);
    $('speechPlay').textContent=playing?'暂停朗读':snapshot.status==='paused'?'继续本句':'播放本句';
    $('speechPosition').textContent=`第 ${snapshot.total?snapshot.index+1:0} / ${snapshot.total} 段`;
    const labels={idle:'准备好后，点击播放。',playing:'正在朗读，听到后输入。',gap:'句间停顿中…',paused:'朗读已暂停，继续时从本句开头重听。',ready:'本句已读完，写好后点「下一句」。',ended:'全文已读完，输入完成后可结束练习。',error:'朗读未成功，请更换声音后重试。'};
    $('speechStatus').textContent=!speechAvailable?'当前浏览器不支持朗读，请使用支持语音合成的浏览器。':!speechVoices.length?'未检测到匹配的朗读声音，可点击重新检测，或在系统中安装对应语言语音包。':locked?'本次练习已结束。':labels[snapshot.status];
  }
  function loadSpeechVoices(){
    if(!speechAvailable){renderDictation();return;}
    const selected=$('speechVoice').value;
    const english=state.article.language==='en';
    speechVoices=window.speechSynthesis.getVoices().filter(v=>english?/^en([-_]|$)/i.test(v.lang):/^(zh|cmn)([-_]|$)/i.test(v.lang));
    speechVoices.sort((a,b)=>Number(/zh[-_]CN|cmn[-_]Hans/i.test(b.lang))-Number(/zh[-_]CN|cmn[-_]Hans/i.test(a.lang))||Number(b.localService)-Number(a.localService));
    $('speechVoice').replaceChildren(...speechVoices.map(v=>{const option=document.createElement('option');option.value=v.voiceURI;option.textContent=v.name+' · '+v.lang+(v.localService?'':' · 在线');return option;}));
    if(speechVoices.some(v=>v.voiceURI===selected))$('speechVoice').value=selected;
    $('speechVoice').disabled=!speechVoices.length;
    renderDictation();
  }
  function speechSettings(){
    dictation?.configure({voice:speechVoices.find(v=>v.voiceURI===$('speechVoice').value)||null,rate:Number($('speechRate').value),punctuation:$('speechPunctuation').checked,continuous:$('speechContinuous').checked,gap:Number($('speechGap').value)*1000});
  }
  function playDictation(delta=0){
    if(!dictation||!speechVoices.length||state.status==='finished'||state.view!=='practice')return;
    if(state.status==='paused')resume();
    speechSettings();
    // Timing keeps the same rule as copy practice: the first entered character starts it.
    if(delta)dictation.move(delta);else dictation.play();
    $('typingInput').focus();
  }
  function requestReset(action) {
    if(active()){pause();pendingAction=action;$('confirmDialog').showModal();}
    else action();
  }
  function useArticle(article) {requestReset(()=>{state.article=article;reset();showView('practice');$('typingInput').focus();});}
  function showView(view) {
    if(view!=='practice')pause();
    state.view=view;
    ['practice','library','history'].forEach(name=>$(name+'View').hidden=name!==view);
    document.querySelectorAll('[data-view]').forEach(el=>{el.classList.toggle('active',el.dataset.view===view);el.setAttribute('aria-current',el.dataset.view===view?'page':'false');});
    if(view==='history')renderHistory();
    if(view!=='practice'){document.body.classList.remove('focus-mode');setFocusLabel();}
  }
  function openCustom() {
    pause();
    try {const saved=JSON.parse(localStorage.getItem(CUSTOM_KEY)||'null');if(saved&&typeof saved.text==='string'){$('customText').value=saved.text;$('customTitle').value=saved.title||'';}}catch{}
    updateCustomCount();$('customError').textContent='';$('customDialog').showModal();
  }
  function updateCustomCount() {$('customCount').textContent=`${core.chars($('customText').value.trim()).length.toLocaleString()} 字符`;}
  function renderArticleSource() {
    const sources=state.article.sources || [];
    $('articleSource').hidden=!sources.length;
    $('articleSource').open=false;
    $('articleSourceContent').replaceChildren();
    if(!sources.length)return;
    const list=document.createElement('ul');
    for(const source of sources){
      const item=document.createElement('li'),link=document.createElement('a');
      let url;try{url=new URL(source.url);}catch{continue;}
      if(url.protocol!=='https:')continue;
      link.href=url.href;link.target='_blank';link.rel='noopener noreferrer';
      link.textContent=source.title+(source.articles?' · '+source.articles:'')+' ↗';
      item.append(link);list.append(item);
    }
    const note=document.createElement('p');
    note.textContent=state.article.sourceNote || '';
    $('articleSourceContent').append(list,note);
  }
  const libraryPageSize=10;
  let libraryPage=1;
  function renderLibrary(page=libraryPage) {
    const pageCount=Math.max(1,Math.ceil(articles.length/libraryPageSize));
    libraryPage=Math.max(1,Math.min(pageCount,Math.trunc(page)||1));
    const offset=(libraryPage-1)*libraryPageSize;
    $('articleGrid').innerHTML=articles.slice(offset,offset+libraryPageSize).map((a,i)=>`<button class="book-card" data-article="${escape(a.id)}"><span class="book-top"><span class="article-tag">第 ${String(offset+i+1).padStart(2,'0')} 篇</span><span class="mini-cat" style="--cat-x: -${i % 5 * 42}px; --cat-y: -${Math.floor((i % 10) / 5) * 56}px" aria-hidden="true"><img src="${collectionSrc}" width="210" height="112" alt=""></span></span><h2>${escape(a.title)}</h2><p>${escape(a.description)}</p><span class="book-bottom"><span>${core.chars(a.text).length.toLocaleString()} 字符 · ${escape(a.difficulty)}</span><span>开始练习 ${icon('arrow')}</span></span></button>`).join('');
    $('articleGrid').querySelectorAll('[data-article]').forEach(b=>b.addEventListener('click',()=>useArticle(articles.find(a=>a.id===b.dataset.article))));
    $('libraryCount').textContent=`共 ${articles.length} 篇 · 每页 ${libraryPageSize} 篇`;
    $('libraryPageStatus').textContent=`第 ${libraryPage} / ${pageCount} 页`;
    $('libraryPrevious').disabled=libraryPage===1;
    $('libraryNext').disabled=libraryPage===pageCount;
    $('libraryPages').innerHTML=Array.from({length:pageCount},(_,i)=>`<button type="button" class="page-button${i+1===libraryPage?' selected':''}" data-page="${i+1}" aria-label="第 ${i+1} 页"${i+1===libraryPage?' aria-current="page"':''}>${i+1}</button>`).join('');
  }
  function changeLibraryPage(page) {
    renderLibrary(page);
    $('libraryPages').querySelector('[aria-current="page"]').focus({preventScroll:true});
    $('libraryView').scrollIntoView({block:'start'});
  }
  function renderHistory() {
    const best=history.length?Math.max(...history.map(r=>r.speed)):0;
    const minutes=history.reduce((n,r)=>n+r.elapsed,0)/60;
    $('historyStats').innerHTML=`<div class="summary-card"><span>累计练习</span><strong>${history.length}<small>次</small></strong></div><div class="summary-card"><span>最高速度</span><strong>${Math.round(best)}<small>字 / 分</small></strong></div><div class="summary-card"><span>专注时长</span><strong>${minutes.toFixed(1)}<small>分钟</small></strong></div>`;
    $('historyCount').textContent=`${history.length} 次`;$('exportButton').disabled=!history.length;
    if(!history.length){$('historyList').innerHTML=`<div class="empty-state"><span>✳</span><h3>你的第一段足迹，即将开始。</h3><p>完成一次练习，就会在这里留下记录。</p><button class="primary-button" id="emptyStart">开始练习 ${icon('arrow')}</button></div>`;$('emptyStart').addEventListener('click',()=>showView('practice'));return;}
    $('historyList').innerHTML=`<div class="history-table-wrap"><table class="history-table"><thead><tr><th>文章 / 时间</th><th>速度</th><th>正确率</th><th>用时</th><th>进度</th></tr></thead><tbody>${history.map(r=>`<tr><td>${escape(r.title)}<small>${new Date(r.at).toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'})} · ${exerciseLabel(r)} · ${r.mode==='timed'?'限时挑战':'自由练习'}${r.reason==='manual'?' · 提前结束':''}</small></td><td><strong>${Math.round(r.speed)}</strong> 字/分</td><td>${r.accuracy.toFixed(1)}%</td><td>${timeText(r.elapsed)}</td><td>${Math.floor(r.progress)}%</td></tr>`).join('')}</tbody></table></div>`;
  }
  function exportHistory() {
    const cell=v=>`"${String(v).replace(/^[=+@-]/,"'$&").replace(/"/g,'""')}"`;
    const rows=[['文章','时间','练习方式','模式','速度（正确字符/分钟）','正确率（%）','用时（秒）','输入字符','正确字符','总字符','完成度（%）'],...history.map(r=>[r.title,new Date(r.at).toLocaleString('zh-CN'),exerciseLabel(r),r.mode==='timed'?'限时挑战':'自由练习',r.speed.toFixed(1),r.accuracy.toFixed(1),r.elapsed.toFixed(1),r.typed,r.correct,r.total,r.progress.toFixed(1)])];
    const url=URL.createObjectURL(new Blob(['\ufeff'+rows.map(row=>row.map(cell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));
    const a=document.createElement('a');a.href=url;a.download=`南瓜头练习记录-${new Date().toLocaleDateString('sv-SE')}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('练习记录已导出');
  }
  function setFocusLabel(){const on=document.body.classList.contains('focus-mode');$('focusButton').setAttribute('aria-label',on?'退出专注模式':'进入专注模式');$('focusButton').title=on?'退出专注模式':'专注模式';$('focusButton').setAttribute('aria-pressed',on);}
  $('typingInput').addEventListener('compositionstart',()=>{if(!['ready','running'].includes(state.status))return;state.composing=true;start();$('compositionStatus').textContent='组词中，选定后计入成绩';});
  $('typingInput').addEventListener('compositionend',()=>{state.composing=false;$('compositionStatus').textContent='';commitInput();if(state.pendingPause){state.pendingPause=false;pause();}});
  $('typingInput').addEventListener('input',e=>{if(!e.isComposing)commitInput();});
  ['paste','drop'].forEach(name=>$('typingInput').addEventListener(name,e=>{e.preventDefault();toast('练习时请逐字输入。自己的文章可通过「自定义文章」添加。');}));
  $('typingInput').addEventListener('beforeinput',e=>{if(['insertFromPaste','insertFromDrop'].includes(e.inputType)){e.preventDefault();toast('练习时请逐字输入');}});
  $('typingInput').addEventListener('keydown',e=>{if(e.key==='Tab'&&!e.shiftKey&&targetChars[core.chars(state.input).length]==='\t'){e.preventDefault();const el=e.target;el.setRangeText('\t',el.selectionStart,el.selectionEnd,'end');commitInput();}});
  $('pauseButton').addEventListener('click',togglePause);$('overlayResume').addEventListener('click',resume);
  document.querySelectorAll('[data-exercise]').forEach(button=>button.addEventListener('click',()=>{if(state.exercise!==button.dataset.exercise)requestReset(()=>{state.exercise=button.dataset.exercise;reset();});}));
  $('speechPlay').addEventListener('click',()=>{if(['playing','gap'].includes(dictation?.snapshot().status))dictation.pause();else playDictation();});
  $('speechPrevious').addEventListener('click',()=>playDictation(-1));
  $('speechNext').addEventListener('click',()=>playDictation(1));
  $('speechRepeat').addEventListener('click',()=>playDictation());
  $('showDictationText').addEventListener('click',()=>{state.revealed=!state.revealed;if(state.revealed)state.peeked=true;renderExercise();updateReference();});
  $('refreshSpeechVoices').addEventListener('click',loadSpeechVoices);
  ['speechVoice','speechRate','speechGap','speechContinuous','speechPunctuation'].forEach(id=>$(id).addEventListener('change',()=>{dictation?.pause();speechSettings();}));
  if(speechAvailable)window.speechSynthesis.addEventListener('voiceschanged',loadSpeechVoices);
  window.addEventListener('pagehide',()=>dictation?.stop());
  $('finishButton').addEventListener('click',()=>finish());
  $('restartButton').addEventListener('click',()=>requestReset(()=>{reset();$('typingInput').focus();}));
  $('switchArticle').addEventListener('click',()=>{const index=articles.findIndex(a=>a.id===state.article.id);useArticle(articles[(index+1)%articles.length]);});
  document.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>{if(state.mode!==b.dataset.mode)requestReset(()=>{state.mode=b.dataset.mode;reset();});}));
  $('duration').addEventListener('change',e=>{const value=Number(e.target.value);$('duration').value=state.limit;if(value!==state.limit)requestReset(()=>{state.limit=value;reset();});});
  document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));
  document.querySelector('.brand').addEventListener('click',e=>{e.preventDefault();showView('practice');});
  $('libraryPrevious').addEventListener('click',()=>changeLibraryPage(libraryPage-1));
  $('libraryNext').addEventListener('click',()=>changeLibraryPage(libraryPage+1));
  $('libraryPages').addEventListener('click',event=>{const button=event.target.closest('[data-page]');if(button)changeLibraryPage(Number(button.dataset.page));});
  $('customButton').addEventListener('click',openCustom);$('libraryCustom').addEventListener('click',openCustom);$('customText').addEventListener('input',updateCustomCount);
  $('customForm').addEventListener('submit',e=>{e.preventDefault();const text=core.normalize($('customText').value.trim()),length=core.chars(text).length;if(length<10||length>5000){$('customError').textContent='请填写 10–5,000 个字符的文章。';$('customText').focus();return;}const title=$('customTitle').value.trim()||'我的自定义文章';try{localStorage.setItem(CUSTOM_KEY,JSON.stringify({title,text}));}catch{toast('当前浏览器无法保存自定义文章，仍可正常练习。');}$('customDialog').close();useArticle({id:'custom',title,text,category:'自定义',difficulty:'专属',language:/[\u4e00-\u9fff]/.test(text)?'zh':'en'});});
  document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.close).close()));
  $('helpButton').addEventListener('click',()=>{pause();$('helpDialog').showModal();});
  $('confirmCancel').addEventListener('click',()=>{pendingAction=null;$('confirmDialog').close();});
  $('confirmOk').addEventListener('click',()=>{const action=pendingAction;pendingAction=null;$('confirmDialog').close();action?.();});
  $('confirmDialog').addEventListener('cancel',()=>pendingAction=null);
  $('resultAgain').addEventListener('click',()=>{$('resultDialog').close();reset();$('typingInput').focus();});
  $('resultHistory').addEventListener('click',()=>{$('resultDialog').close();showView('history');});
  $('exportButton').addEventListener('click',exportHistory);
  $('focusButton').addEventListener('click',()=>{document.body.classList.toggle('focus-mode');setFocusLabel();});
  function applyReferenceSize() {
    document.documentElement.style.setProperty('--reference-size',referenceSize+'px');
    $('decreaseFont').disabled=referenceSize===minReferenceSize;
    $('increaseFont').disabled=referenceSize===maxReferenceSize;
    $('decreaseFont').title=`缩小字号（当前 ${referenceSize}px，最小 ${minReferenceSize}px）`;
    $('increaseFont').title=`放大字号（当前 ${referenceSize}px，最大 ${maxReferenceSize}px）`;
  }
  function changeReferenceSize(step) {
    referenceSize=Math.max(minReferenceSize,Math.min(maxReferenceSize,referenceSize+step));
    applyReferenceSize();
    try {localStorage.setItem(FONT_SIZE_KEY,String(referenceSize));}
    catch {toast(`字号：${referenceSize}px；浏览器存储不可用，暂时无法记住设置。`);return;}
    toast(`字号：${referenceSize}px · 已记住`);
  }
  applyReferenceSize();
  $('decreaseFont').addEventListener('click',()=>changeReferenceSize(-1));
  $('increaseFont').addEventListener('click',()=>changeReferenceSize(1));
  $('soundButton').addEventListener('click',()=>{state.sound=!state.sound;$('soundButton').innerHTML=icon(state.sound?'volume':'volume-off');$('soundButton').classList.toggle('on',state.sound);$('soundButton').setAttribute('aria-label',state.sound?'关闭按键音':'开启按键音');$('soundButton').title=state.sound?'关闭按键音':'开启按键音';toast(state.sound?'按键音已开启':'按键音已关闭');soundTick();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!e.isComposing&&!state.composing&&!document.querySelector('dialog[open]')){e.preventDefault();togglePause();}});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});
  window.addEventListener('beforeunload',e=>{if(active()){e.preventDefault();e.returnValue='';}});
  setInterval(()=>{if(state.status!=='running')return;if(state.mode==='timed'&&elapsed()>=state.limit){finish('timeout');return;}const second=Math.floor(elapsed());if(second!==lastSecond){lastSecond=second;updateMetrics();}},150);
  renderLibrary();renderHistory();reset();setFocusLabel();
  if(!storageAvailable)toast('浏览器本地存储不可用，练习结果可通过导出保存。');
})();
