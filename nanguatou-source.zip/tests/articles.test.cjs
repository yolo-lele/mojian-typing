const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const crypto=require('node:crypto');
const root=path.join(__dirname,'..');
const context={window:{}};
vm.runInNewContext(fs.readFileSync(path.join(root,'articles.js'),'utf8'),context);
const articles=context.window.TYPING_ARTICLES;
test('library replaces the former texts with 25 sourced judgments and 25 labelled adaptations',()=>{
  assert.equal(articles.length,50);
  assert.equal(new Set(articles.map(a=>a.id)).size,50);
  assert.equal(new Set(articles.map(a=>a.text)).size,50);
  for(const kind of ['judgment-original','complaint-adapted'])assert.equal(articles.filter(a=>a.contentKind===kind).length,25);
  for(const a of articles){
    assert.ok(a.id.startsWith('civil-'));
    assert.doesNotMatch(a.text,/[\r\n\u2028\u2029]/,a.id);
    assert.match(a.sources[0].url,/^https:\/\/(ycsfy|rzsfy)\.hncourt\.gov\.cn\/public\/detail\.php\?id=\d+$/);
    assert.ok(a.caseNumber);
    assert.ok(!a.text.includes('\ufffd'));
    assert.doesNotMatch(a.text,/责任编辑|关闭窗口|All right reserved/);
  }
});
test('judgments remove only line breaks while preserving source snapshots and checksums',()=>{
  for(const a of articles.filter(a=>a.contentKind==='judgment-original')){
    const original=fs.readFileSync(path.join(root,'sources',a.sourceKey+'.txt'),'utf8').replace(/\r\n/g,'\n');
    assert.equal(a.text,original.replace(/[\r\n\u2028\u2029]/g,''),a.id);
    assert.doesNotMatch(a.text,/[\r\n\u2028\u2029]/,a.id);
    assert.equal(crypto.createHash('sha256').update(original).digest('hex'),a.sourceSha256);
    assert.match(a.text,/判决如下[：:]/);
    assert.match(a.text,/书\s*记\s*员/);
  }
});
test('adaptations expose provenance and contain pleading sections without invented filing dates',()=>{
  for(const a of articles.filter(a=>a.contentKind==='complaint-adapted')){
    assert.match(a.title,/起诉状改写/);
    assert.match(a.text,/^民事起诉状（依据公开判决书改写）/);
    for(const section of ['原告','被告','诉讼请求：','事实与理由：','证据和证据来源：','此致','起诉人：'])assert.ok(a.text.includes(section),a.id+section);
    assert.ok(a.text.endsWith('具状日期：未见公开记载'));
    const judgment=articles.find(j=>j.contentKind==='judgment-original'&&j.sourceKey===a.sourceKey);
    assert.equal(a.caseNumber,judgment.caseNumber);
    assert.equal(a.sources[0].url,judgment.sources[0].url);
  }
});
