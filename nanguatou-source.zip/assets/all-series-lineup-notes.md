# CAT MODE ON · all ten designs lineup

Created 2026-10-21 for the local preview of 南瓜头 typing practice. This is an AI-generated decorative lineup based on inspected official product photographs, not an official POP MART render. No deployment was performed.

## Final asset

- File: `cat-mode-all-collection.png`
- 1774 × 887 pixels (2:1), PNG with Format32bppArgb; tested corner and top-padding alpha = 0.
- 1,655,922 bytes.
- Built-in image_gen tool with `transparent_background=true`; generated PNG copied unmodified into the project.
- Exactly ten figures in a 5-column × 2-row arrangement.
- Top row left to right: Calico Kitty, Persian Kitty, Ragdoll Kitty, Cow Kitty, Strawberry Kitty.
- Bottom row left to right: Matcha Kitty, Midnight Kitty, Leopard Kitty, Siamese Kitty, Maine Coon Kitty (secret).
- Initial generation was followed by a layout-only edit that added transparent space between figures and completed the rightmost tails.

## References

[Official product page](https://www.popmart.com/ca/products/9210/the-monsters-cat-mode-on-series-vinyl-plush-pendant-blind-box)

All ten local official reference photographs were opened with view_image and inspected before generation. The built-in generator accepts at most five input paths, so the selected actual image inputs were Persian, Cow, Leopard, Siamese and Maine Coon; the other five were specified from their inspected photographs in the detailed prompt.

- **Calico Kitty** (regular): 三花猫：奶白、姜橘、深棕黑拼色毛绒；左半头罩奶白、右半姜橘，尾巴深棕黑；闪绿眼睛，蜜桃色鼻子，浅蜜桃/香槟粉缎带蝴蝶结。 [Official photograph](https://prod-global-biz.popmart.com/globalAdmin/1791542748160_ea71080172c9c09f2f018068297133c8.jpg)
- **Persian Kitty** (regular): 波斯猫：雪白/奶白长毛全身，白色蓬松尾巴；异色瞳（画面左眼琥珀橄榄棕、右眼蓝），粉鼻子，浅冰蓝色长缎带蝴蝶结。 [Official photograph](https://prod-global-biz.popmart.com/globalAdmin/1791542752396_75d23d658c7b92526fd5b204e846a785.jpg)
- **Ragdoll Kitty** (regular): 布偶猫：暖灰米色面框与身体，深巧克力棕猫耳、上肢、尾巴，米灰肚子；蓝色眼睛，蜜桃鼻子，棕色长缎带蝴蝶结。 [Official photograph](https://prod-global-biz.popmart.com/globalAdmin/1791542756427_fc06ec4eb714918a17eea9ebb41b720c.jpg)
- **Cow Kitty** (regular): 奶牛猫：黑色头罩、四肢与尾巴，白色下巴毛领和明显的白肚子，耳内奶白；蓝绿眼睛，黑色鼻子，橄榄绿棕色杂色粗织/花呢短蝴蝶结。 [Official photograph](https://prod-global-biz.popmart.com/globalAdmin/1791542761013_dd8827b197ff237a777643e4d2592d51.jpg)
- **Strawberry Kitty** (regular): 草莓猫：很浅的粉紫/草莓奶昔色蓬松毛绒，奶白肚子，同色尾巴；橄榄绿眼睛，浅金棕鼻子，淡粉紫长缎带蝴蝶结。 [Official photograph](https://prod-global-biz.popmart.com/globalAdmin/1791542765229_662781fd28ee91b11fae3ee5609e33e4.jpg)
- **Matcha Kitty** (regular): 抹茶猫：浅黄绿/奶油抹茶色蓬松毛绒，浅奶油肚子，同色尾巴；金琥珀棕眼睛，蜜桃鼻子，橄榄抹茶绿色长缎带蝴蝶结。 [Official photograph](https://prod-global-biz.popmart.com/globalAdmin/1791542769937_53de57cb371bdf88f6a4046f2da33be7.jpg)
- **Midnight Kitty** (regular): 午夜猫：通体黑色毛绒、黑色肚子及尾巴，耳内白与淡粉；绿色眼睛，蜜桃橘鼻子；鲜红色短款立体布料蝴蝶结，无长丝带。区别于黑白肚子的 Cow。 [Official photograph](https://prod-global-biz.popmart.com/globalAdmin/1791542779434_7ec739ed4876d9c905aa21a3abe8c4f8.jpg)
- **Leopard Kitty** (regular): 豹纹猫：金黄/橙棕底色与大块深棕黑豹纹斑点，尾巴也是深浅斑纹；金橄榄棕眼睛，金棕鼻子；米色黑棕格纹/千鸟格花呢短蝴蝶结。 [Official photograph](https://prod-global-biz.popmart.com/globalAdmin/1791542783593_99186382da4ff899fe6403ba2bdc86ad.jpg)
- **Siamese Kitty** (regular): 暹罗猫：明亮奶白/象牙白头罩与躯干、肚子，深巧克力棕猫耳、双臂和尾巴；深蓝眼睛，深棕鼻子，深藏青色针织短蝴蝶结。比 Ragdoll 更白，且没有棕色长丝带。 [Official photograph](https://prod-global-biz.popmart.com/globalAdmin/1791542787375_70fffe05b5351c336d5cf35d49c40b8e.jpg)
- **Maine Coon Kitty** (secret): 缅因猫隐藏款：烟灰/银灰长毛全身、淡奶灰脸框，尤其蓬松粗大灰尾巴；灰紫色眼睛，银色鼻子，金属银灰短蝴蝶结；冷灰统一配色。 [Official photograph](https://prod-global-biz.popmart.com/globalAdmin/1791542792286_8b52b617c197535d8f741e63bd194db0.jpg)

Local reference catalog: `C:/Users/gmcc/Documents/New project/tmp/cat-mode-all-references/catalog.json`.

## Initial generation prompt

```text
Use case: compositing / identity-preserve.
Asset type: a transparent character sprite sheet for a cute, minimal website header. This image must contain the complete ten-design THE MONSTERS CAT MODE ON plush toy collection, nine regular plus one secret. Create a single wide 2:1 landscape PNG with genuine transparent alpha background, an exact 5-column by 2-row grid, one whole seated toy in each cell. NO TEXT anywhere.

Input images 1 to 5 are official identity reference photographs, in order: Persian Kitty, Cow Kitty, Leopard Kitty, Siamese Kitty, Maine Coon Kitty secret. The other five official designs have been carefully specified below from their corresponding inspected official photographs. Preserve the exact distinctive toy identity, fur costume colors, eyes, nose, bow type, vinyl face, and proportions in each reference. Remove the photographic environments and props; do not recreate any furniture, books, kiwi fruit, laptop, basket, fabric backdrop, or keychain hardware.

MANDATORY GRID ORDER, each design appears once and only once:
TOP ROW, left to right:
1 Calico Kitty: cream-white and ginger-orange and dark-brown patchwork; image-left face surround cream, image-right ginger; dark brown tail; green eyes; peach nose; pale peach/champagne pink long satin bow.
2 Persian Kitty: snow-white fluffy fur and white tail; HETEROCHROMIA image-left eye amber/olive-brown, image-right eye blue; pink nose; ice-blue long satin bow.
3 Ragdoll Kitty: warm taupe-gray/beige fluffy face surround and body, dark chocolate brown outer cat ears, arms and tail; blue eyes; peach nose; brown long satin bow.
4 Cow Kitty: black fur hood, arms, legs, tail with prominent white chin ruff and white belly, cream ear interiors; teal-blue eyes; black nose; small short olive/brown tweed bow. Clearly black and white, not solid black.
5 Strawberry Kitty: extremely pale pink-lilac fluffy costume, cream-white belly, matching pale pink-lilac tail; olive-green eyes; gold-brown nose; pale pink-lilac long satin bow.
BOTTOM ROW, left to right:
6 Matcha Kitty: pale yellow-green fluffy costume, light cream belly, matching tail; amber-brown eyes; peach nose; olive green long satin bow.
7 Midnight Kitty: all-black fluffy costume AND belly and tail, light cream/pink ear interiors; green eyes; peach-orange nose; short bright red fabric bow with no long ribbons. Clearly distinct from Cow.
8 Leopard Kitty: rich ginger-gold fur with large dark brown/black leopard spots including tail; golden olive-brown eyes; gold-brown nose; short beige and black checked tweed bow.
9 Siamese Kitty: bright ivory-white head surround and torso and belly, dark chocolate brown cat ears, arms and tail; dark blue eyes; dark brown nose; short dark navy knitted bow. More white than Ragdoll, no brown long ribbons.
10 Maine Coon Kitty SECRET: long smoky silver-gray fluffy fur with light cream-gray face ruff and an especially thick fluffy silver-gray tail; gray-purple eyes; metallic silver nose; short metallic silver-gray bow.

All ten have the recognizable peach vinyl LABUBU faces, big reflective expressive eyes, mischievous visible toothy smile, and double ear sets, two small triangular cat ears plus two upright LABUBU ears. Plush materials and detailed soft fur, photographed studio product style. Keep authentic differences in bows and fur patterns; no generic recolored clones.

Composition: EXACTLY TEN separate, complete seated toys, five on each of two rows; front-facing neutral seated pose, slight natural head variation, same toy scale and even spacing. Center toys at x=10%,30%,50%,70%,90% and y=25% or75%. Every toy's complete ears, both feet, full body and close curled side tail remain INSIDE its own grid cell. Each toy occupies about 86% of its cell height and no more than 88% of its cell width. Clear transparent padding between every toy, across the horizontal row gap, and along all canvas edges. No overlap, no clipping, no border. No checkerboard painted in. No shadow, no platform, no floor, no frame, no labels, no logo, no lettering, no watermark, no graphic ornaments. Neutral clean daylight lighting on the dolls, with absolutely transparent empty space surrounding them.
```

## Padding refinement prompt

Input: the first generated transparent lineup. All ten identities and order were preserved.

```text
Use case: precise-object-edit / identity-preserve.
The input is a transparent 5-column, 2-row sprite sheet containing exactly 10 CAT MODE ON LABUBU toys. Preserve ALL TEN toy designs, colors, eye colors, fur patterns, facial expressions, bows, exact row order, and their plush photographic rendering. The requested change is only LAYOUT AND PADDING for better website sprites.

Keep the canvas wide 2:1. Keep exactly five figures in the top row and exactly five in the bottom row, in the SAME order as the input: top Calico, Persian, Ragdoll, Cow, Strawberry; bottom Matcha, Midnight, Leopard, Siamese, silver Maine Coon secret. Center each complete toy including tail in its equal 20%-wide by 50%-high rectangular cell. REDUCE EACH WHOLE TOY'S SCALE BY 20% relative to the input, keeping the fur texture clear. There must be wide completely transparent blank gutters around each toy, especially at the right edge and between cells, so that splitting the canvas into five equal columns and two equal rows would NOT cut any ear, tail or foot. Complete Strawberry's currently right-edge-trimmed tail and show Maine Coon's full long fluffy gray tail contained beside it in its cell. Every whole toy including tail must fit within the middle 84% of its cell width and the middle 80% of its cell height, with comfortable transparent padding. No parts may touch another toy or canvas edge. Preserve ten distinct original designs; do not add or remove or duplicate any toy. True transparent alpha background, no floor, no shadows, no decorations, no text, no labels, no frame, no watermark.
```

## Generated originals

- First generation: `C:/Users/gmcc/.codex/generated_images/01a15d3e-0c07-71c3-8129-60a5d142cc8c/exec-a966051e-756a-4b93-9fb7-464ae4480b3f.png`
- Selected final: `C:/Users/gmcc/.codex/generated_images/01a15d3e-0c07-71c3-8129-60a5d142cc8c/exec-cfde6058-a68f-4fb5-abca-0f73d0fcb517.png`

