(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.TypingCore = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';

  // Keep spaces and line breaks meaningful while making equivalent input equal.
  function normalize(text) {
    return String(text == null ? '' : text).replace(/\r\n/g, '\n').normalize('NFC');
  }

  function chars(text) {
    return Array.from(normalize(text));
  }

  function analyze(target, input, elapsedSeconds) {
    var expected = chars(target);
    var entered = chars(input);
    var total = expected.length;
    var typed = entered.length;
    var correct = 0;
    for (var i = 0; i < typed; i += 1) {
      if (i < total && entered[i] === expected[i]) correct += 1;
    }
    var seconds = Number(elapsedSeconds);
    return {
      total: total,
      typed: typed,
      correct: correct,
      incorrect: typed - correct,
      accuracy: typed === 0 ? 100 : (correct / typed) * 100,
      speed: Number.isFinite(seconds) && seconds > 0 ? (correct * 60) / seconds : 0,
      progress: total > 0 ? Math.min((typed / total) * 100, 100) : 0,
      complete: total > 0 && typed >= total
    };
  }

  return Object.freeze({ normalize: normalize, chars: chars, analyze: analyze });
});
