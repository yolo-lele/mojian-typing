# CAT MODE ON assets · 2026-10-21

Created for the requested 南瓜头 typing website refresh. All images are AI-generated website decorations based on inspected official product references, not official POP MART renders.

## Official reference

[THE MONSTERS CAT MODE ON SERIES — Vinyl Plush Pendant Blind Box](https://www.popmart.com/ca/products/9210/the-monsters-cat-mode-on-series-vinyl-plush-pendant-blind-box)

The official page lists Calico Kitty, Persian Kitty, Ragdoll Kitty, Cow Kitty, Strawberry Kitty, Matcha Kitty, Midnight Kitty, Leopard Kitty, Siamese Kitty and secret Maine Coon Kitty.

Selected four styles (left to right in the collection):
- Calico Kitty: cream-white, ginger-orange, dark-brown patchwork fur; green eyes; peach satin bow.
- Matcha Kitty: pale yellow-green fur; amber/brown eyes; olive-green satin bow.
- Ragdoll Kitty: warm gray-beige fur and dark-brown ears/limbs/tail; blue eyes; brown satin bow.
- Strawberry Kitty: pale pink-lilac fur; olive-green eyes; lavender satin bow.

Downloaded official reference files (inspected before generation):
- Ragdoll: https://prod-global-biz.popmart.com/globalAdmin/1791542756427_fc06ec4eb714918a17eea9ebb41b720c.jpg
- Matcha: https://prod-global-biz.popmart.com/globalAdmin/1791542769937_53de57cb371bdf88f6a4046f2da33be7.jpg
- Calico: https://prod-global-biz.popmart.com/globalAdmin/1791542748160_ea71080172c9c09f2f018068297133c8.jpg
- Strawberry: https://prod-global-biz.popmart.com/globalAdmin/1791542765229_662781fd28ee91b11fae3ee5609e33e4.jpg

## Collection asset

File: `cat-mode-collection.png`. Built-in image_gen tool, transparent_background=true. Original generated file copied without pixel edits. 2172 × 724 (3:1).

Prompt:

Use case: compositing. Asset type: transparent horizontal four-toy decorative lineup for a minimal typography-focused website. Input images 1-4 are official product character references, not backgrounds: 1 Ragdoll Kitty, 2 Matcha Kitty, 3 Calico Kitty, 4 Strawberry Kitty from THE MONSTERS CAT MODE ON series. Create a single wide 3:1 landscape transparent PNG containing exactly these four full seated LABUBU toys, arranged left to right as Calico, Matcha, Ragdoll, Strawberry. Preserve each official design faithfully: Calico has cream-white, ginger orange and dark brown patchwork fur, green eyes and peach bow; Matcha has pale yellow-green plush fur, amber brown eyes and olive-green satin bow; Ragdoll has warm gray-beige fur, dark brown limbs/outer ears/tail, blue eyes and brown bow; Strawberry has pale pink-lilac fluffy fur, olive-green eyes, pale lavender bow and cream belly. Preserve their distinctive cheeky smiling toothy vinyl face and their double sets of ears, two small triangular cat ears and two tall LABUBU ears. Soft detailed photographed plush texture and gentle neutral daylight. All four face the viewer with slight individual head tilts, at the same scale, generous clear transparent gaps, tails contained close beside their own bodies. Entire ears, feet and tails fit inside the canvas. Keep dolls about 82 percent of canvas height, about 10 percent transparent vertical padding. Genuine transparent alpha background, no floor, no room, no shadows, no props, no books, no fruit, no laptop, no strings or metal hanging hardware, no writing, no brand logo, no text, no watermark, no border. Do not invent extra costumes or colors. The whole visual must be a light, clean asset rather than a poster.

## Cursor asset

File: `cat-mode-cursor.png`. Built-in image_gen tool, transparent_background=true. Original generated file copied without pixel edits. Ragdoll Kitty head only, no pointer arrow, suited to an overlay that replaces the native pointer.

Prompt:

Use case: background-extraction. Asset type: transparent LABUBU head icon that will entirely replace a mouse pointer. Input image is the official Ragdoll Kitty CAT MODE ON product reference. Isolate and reframe the Ragdoll Kitty's head ONLY into a centered front-facing compact square transparent PNG, preserving the exact warm gray-beige fluffy fur, darker brown outer cat ears, two tall cream LABUBU ears, two small triangular cat ears, peach vinyl face, big glossy blue eyes and recognizably mischievous nine-tooth white smile. The head should occupy 90 percent of the square and retain complete ears. No torso, no hands, no bow, no laptop, no background, no arrow, no crosshair, no cursor symbol, no circle frame, no border, no text, no watermark. Genuine transparent alpha around the furry silhouette. Photographed plush-toy material with clean recognizable features, suitable for a crisp 48px website pointer. Do not stylize into generic flat bunny art.

