# Strawberry Kitty theme assets

Official reference: https://prod-global-biz.popmart.com/globalAdmin/1791542765229_662781fd28ee91b11fae3ee5609e33e4.jpg

Official product: https://www.popmart.com/ca/products/9210/the-monsters-cat-mode-on-series-vinyl-plush-pendant-blind-box

Asset: `labubu-strawberry.png`

Method: Built-in `image_gen.imagegen`, background extraction/edit, `transparent_background: true`. The reference photograph was viewed before editing. The generated PNG was copied into the project without modifying its pixels or alpha.

Final prompt:

Use case: background-extraction. Asset type: a small transparent product sticker for a minimal feminine typing website. Edit target: the supplied official reference photograph. Isolate ONLY the seated Strawberry Kitty LABUBU plush toy. Preserve exactly its recognizable peach face, olive-green eyes, toothy smile, tall original LABUBU ears and small cat ears, fluffy near-white blush-pink cat costume, pale lavender satin bow, cream belly, long fluffy tail, seated pose, tiny hands and feet. Keep the full toy, including all ears, tail and feet, fully inside the frame with a little clean padding. Preserve the photographed toy's identity, costume, proportions, gentle lighting and detailed soft fur. Remove the yellow cat tree, blue platform, yarn ball, floor, curtain, furniture, dangling ball and every background element. No ground shadow, no props, no added decoration, no border, no text, no logo, no watermark. Genuine transparent alpha background. Do not redesign the toy, do not turn it into a generic bunny, and do not invent a different outfit.

## Study poster background — 2026-10-21

Asset: `labubu-study-poster.png`

Method: Built-in `image_gen.imagegen`, new decorative landscape composition using the existing `labubu-strawberry.png` as the character and material reference. The reference was viewed before generation. The generated image was copied into this project without pixel edits. This is an AI-generated decorative poster, not an official POP MART poster.

Final prompt:

Use case: stylized-concept. Asset type: full-screen decorative desktop background poster for a minimalist feminine typing practice website at 1920 x 1080. Input image 1 is a character and material reference, not a layout to copy. Create one wide 16:9 landscape composition. Preserve the recognizable LABUBU face, mischievous white teeth, glossy olive eyes, pale strawberry-pink furry cat costume, little paws and lavender satin bow seen in the reference. Arrange four small-to-medium LABUBU strawberry-cat toys around only the far left and far right margins, in different gentle poses: upper left peeking, lower left sitting and reading a tiny cream book, upper right a shy wave, lower right sitting beside a small strawberry. Treat these as the same toy character in separate decorative poses. Keep the central 65 percent of the image almost empty and very pale warm ivory with a barely visible blush gradient so an opaque central reading interface will remain easy to use. Furry 3D designer toy photography, softly lit, premium product-campaign quality. Delicate lavender ribbons and a few tiny strawberries near the edge characters only. Clean cream, strawberry pink, pale lavender palette. Peaceful, uncluttered, cute and refined, not childish visual noise. Clear enough characters at the edges, generous negative space, no central character. No writing, no letters, no typography, no logos, no watermark, no website UI, no interface boxes. Do not make a whole webpage, only the decorative poster background.
